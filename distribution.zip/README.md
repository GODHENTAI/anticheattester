# 🎧 Audacity 12 — Official Distribution Guide

Welcome to the distribution package for **Audacity 12**. This guide contains all the vital information, requirements, and instructions needed to run the application successfully on your device.

---

> [!IMPORTANT]
> ### ⚠️ CRITICAL BACKEND SELECTION INSTRUCTION
> When launching **Audacity 12**, the console will prompt you to select a memory backend:
> 
> ```text
> [1] Driver Mode  (physmeme kernel driver)
> [2] Luck Mode    (direct syscall, no driver)
> ```
> 
> **You MUST select option `[2] Luck Mode` (direct syscalls).**
> - **DO NOT USE option `[1] Driver Mode`.** It requires a vulnerable kernel driver that is not included in this package and will not function. Selecting it could also trigger system security blocks, instability, or integrity failures. 
> - **Option `[2]` (Luck Mode)** uses advanced direct syscall execution (completely user-mode safe), bypassing standard system hooks and security checks natively without requiring reboots or installing custom drivers.

---

## 📋 System Requirements & Dependencies

Before running `audacity12.exe`, ensure your system meets the following requirements and has these dependencies installed:

### 1. Core Prerequisites
*   **Operating System:** Windows 10 or Windows 11 (64-bit editions only).
*   **Target Application:** A running instance of the 64-bit Roblox Client.

### 2. Runtime Libraries (Mandatory)
If you encounter DLL error messages (e.g., *MSVCP140.dll* or *VCRUNTIME140.dll is missing*), you must install:
*   **Microsoft Visual C++ Redistributable 2015–2022 (x64)**
    *   👉 [Official Microsoft Download Link](https://aka.ms/vs/17/release/vc_redist.x64.exe)

### 3. Graphics & Rendering
*   **DirectX 11:** The visual overlay is rendered via DirectX 11. Ensure your graphics drivers (NVIDIA, AMD, or Intel) are up to date to prevent overlay lag or initialization crashes.

### 4. Privilege Requirements
*   **Administrator Access:** The application *requires* administrative privileges to interface with external memory regions. You **must** right-click `audacity12.exe` and select **Run as Administrator**.

---

## 🚀 How to Launch and Use

1.  **Launch Roblox:** Open the client and join a game.
2.  **Run Audacity 12:**
    *   Right-click `audacity12.exe` in this folder.
    *   Select **Run as Administrator**.
3.  **Choose Backend:**
    *   Type **`2`** into the console and press **Enter**.
    *   You should see: `[+] Using LUCK backend (direct syscall)`
4.  **Enjoy:**
    *   The ImGui overlay will automatically attach and render on top of your game client.
    *   Configure settings, ESP, aimbot, and features directly via the overlay UI.

---

## 📂 Configuration Management

Your configurations are automatically created and managed in your local AppData directory:
*   **Config Path:** `%appdata%\audacity12\configs\`
*   You can save and load custom `.aud12` setups directly through the overlay's configuration tab.

---

## 🔄 Auto-Update Utility

This package now includes **`updater.exe`**, a standalone C++ utility that simplifies getting the latest builds of **Audacity 12**:
1. Run **`updater.exe`** as Administrator.
2. It will automatically download, extract, and apply the latest update package from the repository.
3. If `audacity12.exe` is currently running, the updater will safely terminate it to release file locks before writing files.
4. Once completed, it clean-updates all local files and offers to launch the application.
