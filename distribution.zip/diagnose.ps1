# Audacity12 - Roblox Diagnostic Script
# Run as: powershell -ExecutionPolicy Bypass -File diagnose.ps1
# Paste the FULL output to the person who gave you this script.

Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  Audacity12 - Roblox Diagnostic" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

# ---- 1. System Info ----
Write-Host "[1] System Info" -ForegroundColor Yellow
Write-Host "    OS: $((Get-WmiObject Win32_OperatingSystem).Caption)"
Write-Host "    Username: $env:USERNAME"
Write-Host "    LocalAppData: $env:LOCALAPPDATA"
Write-Host ""

# ---- 2. Roblox Version ----
Write-Host "[2] Roblox Version" -ForegroundColor Yellow
$robloxVersions = @(
    "$env:LOCALAPPDATA\Roblox\Versions",
    "$env:PROGRAMFILES\Roblox\Versions",
    "${env:PROGRAMFILES(x86)}\Roblox\Versions"
)
$versionFound = $false
foreach ($vPath in $robloxVersions) {
    if (Test-Path $vPath) {
        Write-Host "    Found version folder: $vPath"
        Get-ChildItem $vPath -Directory | ForEach-Object { Write-Host "      -> $($_.Name)" }
        $versionFound = $true
    }
}

# Check registry for Roblox version
$regPaths = @(
    "HKCU:\Software\Roblox",
    "HKLM:\Software\Roblox",
    "HKLM:\Software\WOW6432Node\Roblox"
)
foreach ($reg in $regPaths) {
    if (Test-Path $reg) {
        Write-Host "    Registry: $reg"
        Get-ItemProperty $reg -ErrorAction SilentlyContinue | Format-List | Out-String | Write-Host
    }
}

if (-not $versionFound) {
    Write-Host "    No version folder found in standard paths" -ForegroundColor Red
}

# Try Roblox API for current version
try {
    $api = Invoke-RestMethod "https://clientsettings.roblox.com/v2/client-version/WindowsPlayer" -TimeoutSec 5
    Write-Host "    API current version:      $($api.version)"
    Write-Host "    API clientVersionUpload:  $($api.clientVersionUpload)"
} catch {
    Write-Host "    Could not reach Roblox API: $_" -ForegroundColor Red
}
Write-Host ""

# ---- 3. Log Locations ----
Write-Host "[3] Roblox Log Locations" -ForegroundColor Yellow
$logPaths = @(
    "$env:LOCALAPPDATA\Roblox\logs",
    "$env:LOCALAPPDATA\Packages\ROBLOXCORPORATION.ROBLOX_55nm5eh3cm0pr\LocalState\logs",
    "$env:LOCALAPPDATA\Packages\ROBLOXCorporation.ROBLOX_55nm5eh3cm0pr\LocalState\logs"
)
$foundLogs = @()
foreach ($lp in $logPaths) {
    if (Test-Path $lp) {
        Write-Host "    EXISTS: $lp" -ForegroundColor Green
        $logs = Get-ChildItem $lp -Filter "*Player*.log" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
        if ($logs) {
            Write-Host "    Player logs found: $($logs.Count)"
            $logs | Select-Object -First 5 | ForEach-Object {
                Write-Host "      $($_.Name)  ($($_.LastWriteTime))"
            }
            $foundLogs += $logs | Select-Object -First 1
        } else {
            Write-Host "    No Player*.log files here" -ForegroundColor Red
        }
    } else {
        Write-Host "    NOT FOUND: $lp"
    }
}
Write-Host ""

# ---- 4. DataModel Pattern Scan ----
Write-Host "[4] DataModel Pattern Scan (latest log)" -ForegroundColor Yellow
if ($foundLogs.Count -gt 0) {
    $latestLog = $foundLogs[0]
    Write-Host "    Reading: $($latestLog.FullName)"
    Write-Host "    File size: $([math]::Round($latestLog.Length / 1KB, 1)) KB"

    $keywords = @("datamodel", "DataModel", " dm ", "dm 0x", "initialized", "join:", "FakeDataModel",
                  "UgcExperience", "UGCGame", "game address", "PlaceId", "placeId")

    try {
        # Use FileStream with FileShare.ReadWrite to handle locked log files (Roblox keeps them open)
        $fs = [System.IO.File]::Open($latestLog.FullName, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $reader = New-Object System.IO.StreamReader($fs)
        $content = $reader.ReadToEnd()
        $reader.Close()
        $fs.Close()
        $lines = $content -split "`n"
        $matched = $lines | Where-Object {
            $line = $_
            $keywords | Where-Object { $line -match [regex]::Escape($_) }
        }

        if ($matched) {
            Write-Host "    Matched lines (last 15):" -ForegroundColor Green
            $matched | Select-Object -Last 15 | ForEach-Object {
                $trimmed = $_.Trim()
                if ($trimmed.Length -gt 250) { $trimmed = $trimmed.Substring(0,250) + "..." }
                Write-Host "      $trimmed"
            }
        } else {
            Write-Host "    NO matching lines found in log!" -ForegroundColor Red
            Write-Host "    Last 10 lines of log:" -ForegroundColor Yellow
            $lines | Select-Object -Last 10 | ForEach-Object { Write-Host "      $_" }
        }
    } catch {
        Write-Host "    ERROR reading log file: $_" -ForegroundColor Red
    }
} else {
    Write-Host "    No log files found to scan!" -ForegroundColor Red
}
Write-Host ""

# ---- 5. MoonArea3 Version-Specific URL Check ----
Write-Host "[5] MoonArea3 Offset Availability" -ForegroundColor Yellow
try {
    $api = Invoke-RestMethod "https://clientsettings.roblox.com/v2/client-version/WindowsPlayer" -TimeoutSec 5
    $ver = $api.clientVersionUpload
    $url = "https://raw.githubusercontent.com/MoonArea3/roblox-offsets/refs/heads/main/offsets/$ver/offsets.json"
    Write-Host "    Trying: $url"
    try {
        $offsets = Invoke-RestMethod $url -TimeoutSec 5
        Write-Host "    SUCCESS: version-specific offsets found for $ver" -ForegroundColor Green
        Write-Host "    FakeDataModel.Pointer = $($offsets.FakeDataModel.Pointer)"
        Write-Host "    VisualEngine.Pointer  = $($offsets.VisualEngine.Pointer)"
    } catch {
        Write-Host "    MISS: no per-version offsets for $ver (fallback to latest will be used)" -ForegroundColor Yellow
        $latestUrl = "https://raw.githubusercontent.com/MoonArea3/roblox-offsets/main/latestoffsets.json"
        Write-Host "    Trying fallback: $latestUrl"
        try {
            $latest = Invoke-RestMethod $latestUrl -TimeoutSec 5
            Write-Host "    Fallback OK: latest offsets version = $($latest.version)" -ForegroundColor Green
            Write-Host "    FakeDataModel.Pointer = $($latest.FakeDataModel.Pointer)"
            Write-Host "    VisualEngine.Pointer  = $($latest.VisualEngine.Pointer)"
        } catch {
            Write-Host "    FALLBACK ALSO FAILED: $_ " -ForegroundColor Red
        }
    }
} catch {
    Write-Host "    Could not reach Roblox API to determine version: $_" -ForegroundColor Red
}
Write-Host ""

Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  Done. Copy everything above and" -ForegroundColor Cyan
Write-Host "  send it back." -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
